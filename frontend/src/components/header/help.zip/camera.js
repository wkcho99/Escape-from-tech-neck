import React, { useState, useEffect, useRef } from "react";
import Webcam from "react-webcam";
import "./camera.css"
  let toggle = "stop";
  function checkPos(props,text,posture,setPosture){
    console.log("result:",text)
            //if bad posture 
            if(text != "0") 
            {
              console.log("sound",props.alarm);
              setPosture(posture => posture+1);
              console.log("bad after",posture);
            }
            //else
            else {
              setPosture(0);
            }
            console.log(posture);
            //if bad posture for 3 times, alert
            if(posture == 3) goAlert();
            return (
              <div>{props.alarm}</div>
            );
  }
  const goAlert = function(props){
    console.log("goalert", props.alertType);
    if(props.alertType==0) alertSounds();
    else if(props.alertType == 1) alertPop();
    else
    {
      alertSounds();
      alertPop();
    }
    return (
      <div>{props.alertType}</div>
    );
  }

  const alertSounds = function(props){
    const sound1 = new Audio('/src/sound1.mp3');
    const sound2 = new Audio('/src/sound2.mp3');
    const sound3 = new Audio('/src/sound3.mp3');
    const sound4 = new Audio('/src/sound4.mp3');
    if(props.alarm == "sound1") {
      console.log("sound1");
      sound1.play();
      sound1.loop = false;
      sound1.pause();
    }
    if(props.alarm == "sound2") {
      console.log("sound2");
      sound2.play();
      sound2.loop = false;
      sound2.pause();
    }
    if(props.alarm == "sound3") {
      console.log("sound3");
      sound3.play();
      sound3.loop = false;
      sound3.pause();
    }
    if(props.alarm == "sound4") {
      console.log("sound4");
      sound4.play();
      sound4.loop = false;
      sound4.pause();
    }
    return (
      <div>{props.alarm}</div>
    );
  }
  const alertPop = function(){
    alert();
  }
  const TestOverlay = (props) => {
    const [buttonName,setButtonName] = useState("start tracking");
    const webcamRef = React.useRef(null);
    const [imgSrc, setImgSrc] = useState(null);
    const [posture, setPosture] = useState(0);
    const [result, setResult] = useState("");
    const canvasRef = useRef();
    const imageRef = useRef();
    const videoRef = useRef();
    // Get camera feed
    useEffect(() => {
      async function getCameraStream() {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: true,
        });
    
        if (videoRef.current) {      
          videoRef.current.srcObject = stream;
        }
      };
    
      getCameraStream();
    }, []);

    // Send iage to API
    useEffect(() => {

      const interval = setInterval(async () => {
        if(toggle == "stop"){
          return () => clearInterval(interval);
        } 
        else {
          captureImageFromCamera();

          if (imageRef.current) {
            const formData = new FormData();
            formData.append('image', imageRef.current);

            const response = await fetch('/classify', {
              method: "POST",
              body: formData,
            });
            if (response.status === 200) {
              
              const text = await response.text();
              setResult(text);
              checkPos(props, text, posture,setPosture);
            } else {
              setResult("Error from API. ");
            }
          }
        }
      }, 5000); // <- interval in ms
      return () => clearInterval(interval);
    }, []);
    
    const playCameraStream = () => {
      if (videoRef.current) {
        videoRef.current.play();
      }
    };

    const captureImageFromCamera = () => {
      const context = canvasRef.current.getContext('2d');
      const { videoWidth, videoHeight } = videoRef.current;
  
      canvasRef.current.width = videoWidth;
      canvasRef.current.height = videoHeight;
  
      context.drawImage(videoRef.current, 0, 0, videoWidth, videoHeight);
  
      canvasRef.current.toBlob((blob) => {
        imageRef.current = blob;
      })
    };

    const toggleAlert=function(){
      if(toggle=="stop") {
        toggle = "start";
        setButtonName("stop tracking");
      }
      else if(toggle=="start") {
        toggle = "stop";
        setButtonName("start tracking");
      }
    }
  
    return (
      <>
        <main>
          <video ref={videoRef} onCanPlay={() => playCameraStream()} id="video" />
          <canvas ref={canvasRef} hidden></canvas>
          <p>Currently seeing: {result}</p>
        </main>
        <div className ="startTrack">
          <button className="startBut" onClick={toggleAlert}>
              {buttonName}
          </button>
          
        </div>
        {imgSrc && (
          <img
            src={imgSrc}
          />
        )}
      </>
    );
  };

  export {TestOverlay,checkPos,goAlert,alertSounds};