import React, { useState } from "react";
import "./header.css"
import {Link,BrowserRouter as Router} from 'react-router-dom';
import Modal from 'react-modal';
import {TestOverlay,checkPos,alertSounds} from "../camera/camera";
const customStyles = {
    content: {
        width: '18%',
        height: '60%',
        top:'11.5%',
        left: '72%',
        position:'absolute',
        border: '3px solid #09AA7C',
    },
  };
  Modal.setAppElement('#root');

const Header = () => {
    let sub;
    const [modalIsOpen, setIsOpen] = useState(false);
    function openModal() {
        setIsOpen(true);
      }
    
      function afterOpenModal() {
        sub.style.color = '#033A2B';
      }
    
      function closeModal() {
        setIsOpen(false);
      }
      const [sound, setSound] = useState("sound1");
      console.log(sound);
function soundChange(){
    var sel = document.getElementById("alertSound");
    var selval = sel.options[sel.selectedIndex].value;
    console.log(selval);
    setSound(selval);
}
    return (
        <div className="header">
            <div id = "title">
                <Link to = "/">
                ETN
                </Link>
            </div>
            <div id = "subtitle">
                escape from tech neck
            </div>
            <>
            <button className = "settingButton" onClick ={openModal}>
            </button>
            <Modal isOpen={modalIsOpen} style = {customStyles} onRequestClose={closeModal}>
                <div className="settings">Settings</div>
                <div className ="sounds">
                    Sounds
                    </div>
                    <ul>
                        <div className = "soundop">
                        <li>Alerting Sound</li>
                        <div className = "soundt">
                            <select name = "alert" id="alertSound" onChange={soundChange}>
                                <option value="sound1">sound1</option>
                                <option value="sound2">sound2</option>
                                <option value="sound3">sound3</option>
                                <option value="sound4">sound4</option>
                            </select>
                        </div>
                        <li>Volume</li>
                        <input type = "range"></input>
                        </div>
                    </ul>
                <div className ="break">
                    Break time
                    </div>
                    <ul>
                        <div className="breakop">
                        <li>alarm every</li>
                        </div>
                    </ul>
            </Modal>
            </>
            <div className = "menu">
            <div class = "option">
            <Link to ="/start/step1">
                Start
            </Link>
            </div>
            <div class = "option">
            <Link to ="/exercise">
                Exercise 
            </Link>
            </div>
            <div class = "option">
            <Link to ="/help">
                Help 
            </Link>
            </div>
            <div class = "option">
            <Link to ="/record">
                Record
            </Link>
            </div>
            </div>
            <hr/>
            <TestOverlay alarm = {sound} />
            <checkPos alarm = {sound} />
            <alertSounds alarm = {sound} />
        </div>
        
    );
    
  };
export default Header